def print_number_triangle(number_of_rows):
    # TODO
    pass


print_number_triangle(3)
print_number_triangle(4)


def print_triangle(number_of_rows):
    # TODO
    pass


print_triangle(4)
