inhabitants_and_cities = [(15_000_000, "New York"), (400_000, "Zürich"),
                          (250_000, "Kiel"), (550_000, "Bremen"),
                          (2_000_000, "Hamburg"), (250_000, "Aachen")]

# TODO
