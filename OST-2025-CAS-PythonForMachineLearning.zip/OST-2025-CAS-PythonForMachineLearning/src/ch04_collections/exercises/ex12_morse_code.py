def to_morse_code(input):
    pass


print(to_morse_code("SOS"))
print(to_morse_code("TWEET"))
