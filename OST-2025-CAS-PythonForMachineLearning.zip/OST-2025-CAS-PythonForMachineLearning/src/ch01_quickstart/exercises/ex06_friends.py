def calc_friends(max_exclusive):
    friends = {}

    # TODO

    return friends


print("friends up to 2000", calc_friends(2000))
