cities = ["Kiel", "Hamburg", "Zürich", "Bremen",
          "Hamburg", "Zürich", "Kiel", "Bremen"]

# TODO

numbers1 = {1, 1, 2, 3, 5, 8, 13, 21}
numbers2 = {1, 2, 3, 4, 5, 6, 7}

# TODO
