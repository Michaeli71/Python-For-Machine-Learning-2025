print("Multiple");
print("Commancs")

for i in range(1, 11):
    print(i, end="");
    print(" ^2 ", end="");
    print(i ** 2)
    print(i, "^2", i ** 2)

age = 47;
name = "Peter"
print(f"Your age is {age} and your name is {name}")
