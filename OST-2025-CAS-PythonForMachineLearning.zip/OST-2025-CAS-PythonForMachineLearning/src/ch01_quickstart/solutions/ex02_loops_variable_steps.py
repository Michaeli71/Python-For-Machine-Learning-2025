i = 0
step = 1
while i < 60:
    print("i:", i, "und step:", step)
    i += step
    step += 1
