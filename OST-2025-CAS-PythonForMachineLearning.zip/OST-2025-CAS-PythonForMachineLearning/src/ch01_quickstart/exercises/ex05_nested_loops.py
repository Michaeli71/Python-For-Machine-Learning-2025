def print_letter_triangle(number_of_rows):
    # TODO
    pass


print_letter_triangle(3)
print_letter_triangle(4)
