def last_index_of(values, search_for):
    pass


def rfind(values, search_for):
    pass


print(last_index_of([1, 2, 3, 2, 4, 2, 5, 2], 2))  # => 7
print(last_index_of([1, 2, 3, 2, 4, 2, 5, 2], 7))  # => -1


# print(rfind([1, 2, 3, 2, 4, 2, 5, 2], 7))  # => 7


######################################

def last_index_of(values, search_for, startpos=None):
    pass


def rfind(values, search_for, startpos=None):
    pass


print(last_index_of([1, 2, 3, 2, 4, 2, 5, 2], 2, 6))  # => 5
print(last_index_of([1, 2, 3, 2, 4, 2, 5, 2], 2, 4))  # => 3
