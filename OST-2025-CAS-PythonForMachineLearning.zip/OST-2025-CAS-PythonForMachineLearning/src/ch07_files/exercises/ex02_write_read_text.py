info = """This is the first line
This is the second line
Fun with multiline strings
This picture is brilliant
"""

# TODO
