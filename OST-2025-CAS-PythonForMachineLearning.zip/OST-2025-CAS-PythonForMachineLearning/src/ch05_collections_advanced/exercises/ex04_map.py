# Achtung Fallstrick, weil String Iterable ist
countries = ["USA", "Schweiz", "Deutschland", "Frankreich", "Italien"]

# TODO
